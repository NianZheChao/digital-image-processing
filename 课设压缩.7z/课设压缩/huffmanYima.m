load SqueezeFig0804(a);
g = huff2mat(c);
