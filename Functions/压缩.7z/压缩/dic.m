classdef dic
     properties
         code=''
     end
end