%�ṹ��
classdef Huffman
   properties
      leftNode = []
      rightNode = []
      probability
      code = ''
      character
   end
end