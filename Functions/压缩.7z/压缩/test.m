c = containers.Map;
c('foo') = 1;
c(' not a var name ') = 2;
keys(c)
values(c);